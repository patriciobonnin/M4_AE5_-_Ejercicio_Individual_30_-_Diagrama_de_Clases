package tienda;

public class Envio {

    private String fechaEnvio;
    private String direccionEnvio;

    public Envio(String fechaEnvio, String direccionEnvio) {
        this.fechaEnvio = fechaEnvio;
        this.direccionEnvio = direccionEnvio;
    }

    public String getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(String fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    @Override
    public String toString() {
        return "Envio{" +
                "fechaEnvio='" + fechaEnvio + '\'' +
                ", direccionEnvio='" + direccionEnvio + '\'' +
                '}';
    }
}
